package ua.volyn.vcolnuft;

public record ApiResponse(String fact, int length) {}