package ua.volyn.vcolnuft;

import java.io.FileWriter;
import java.io.IOException;

public class CsvWriter {

    public static void write(ApiResponse response) {
        try (FileWriter writer = new FileWriter("fact.csv", true)) {

            // Якщо файл порожній — додати заголовки
            if (new java.io.File("fact.csv").length() == 0) {
                writer.write("fact,length\n");
            }

            writer.write("\"" + response.fact().replace("\"", "'") + "\"," + response.length() + "\n");

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
